# 重生之我叫 Jensen Huang — Vercel 全栈版

包含完整前端游戏 (`public/index.html`) 与全网流量统计接口 (`api/stats.js`)。

## 快速部署到 Vercel

### 方法一：Vercel CLI 一键部署（最快）
1. 解压本压缩包，进入文件夹目录。
2. 在终端运行：
   ```bash
   npx vercel --prod
   ```
3. 登录你的 Vercel 账号并一路回车确认，几秒钟后即可获得 `https://xxx.vercel.app` 公开网址！

### 方法二：通过 GitHub 导入 Vercel
1. 将解压后的全部文件上传到你的 GitHub 仓库。
2. 登录 Vercel 控制台 -> **Add New Project** -> 选择该仓库并点击 **Deploy**。

## 开启持久化全网流量统计（可选）
* 默认情况下 `/api/stats` 已内置内存统计；如需在多实例间永久保存全网玩家的访问量与结局分布：
  1. 在 Vercel 项目后台 **Storage** 中免费创建一个 **Upstash Redis**（或 Vercel KV）并绑定到当前项目。
  2. 重新部署一次即可自动启用 Redis 持久化统计。
* 也可在 Vercel 后台直接开启 **Analytics (Web Analytics)** 查看全球访客来源与设备统计。
